using System;

public partial class  Page_AT101000 : PX.Web.UI.PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}
